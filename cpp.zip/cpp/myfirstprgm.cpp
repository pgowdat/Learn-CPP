#include <iostream>
using namespace std;

/* this is my first program*/

int main() {
  cout << "HI PAVAN";
  return 0;
}